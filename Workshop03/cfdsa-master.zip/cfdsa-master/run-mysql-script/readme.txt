Mount a volume under /scripts with a SQL script called main.sql
